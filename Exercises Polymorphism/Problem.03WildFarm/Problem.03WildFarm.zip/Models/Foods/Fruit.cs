﻿using Problem._03WildFarm.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Problem._03WildFarm
{
    public class Fruit : Food
    {
        public Fruit(int quantity) 
            : base(quantity)
        {
        }
    }
}
