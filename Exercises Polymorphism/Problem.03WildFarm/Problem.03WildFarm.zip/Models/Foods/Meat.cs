﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem._03WildFarm.Models.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity) 
            : base(quantity)
        {
        }
    }
}
