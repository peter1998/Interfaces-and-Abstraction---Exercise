﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem._06
{
   public interface IAge
    {
        int Age { get; set; }
    }
}
