﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem._06
{
    public interface IID
    {
        string Id { get; set; }
    }
}
