﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem._06
{
    public interface IBirthDate
    {
        DateTime BirthDate { get; set; }
    }
}
