﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem._04
{
    public interface IBrowsing
    {
        string Browsing(string website);
    }
}
